# ReceiScan Android Studio Package

This package wraps the existing ReceiScan mobile HTML/CSS/JavaScript application with Capacitor so it can run as a real Android application.

## Required on Windows
1. Install Android Studio.
2. Install Android SDK Platform and Android SDK Build-Tools from SDK Manager.
3. Install Node.js LTS.
4. Open this folder in VS Code/PowerShell.
5. Run `npm install`.
6. Run `npx cap add android` (first setup only).
7. Run `npx cap sync android`.
8. Run `npx cap open android`.
9. In Android Studio, select an emulator or connected phone and press Run.

## Build APK
In Android Studio: Build > Build App Bundle(s) / APK(s) > Build APK(s).
For a release APK use Build > Generate Signed App Bundle / APK.

## Important phone settings
- Enable Developer Options and USB debugging if using a USB-connected Android phone.
- Allow camera permission when ReceiScan requests it.
- Allow photo/file access when selecting a receipt from the gallery.
- The current OCR library is loaded from a CDN by the existing web app, so Internet permission/connectivity is required for OCR unless OCR assets are bundled locally later.

## Button/mobile behavior
The source HTML is copied unchanged from the current ReceiScan reference UI. Capacitor provides the Android WebView container. If a button does not respond in the browser, fix the web source first; Android packaging alone cannot repair a JavaScript error.

## Backend
This package does not automatically include the Spring Boot/MySQL backend. The current HTML prototype stores browser-side data locally. For shared multi-user data, connect the app to the Spring Boot API and MySQL project.
