$ErrorActionPreference = 'Stop'
Write-Host '=== ReceiScan Android Setup ==='
node --version
npm --version
if (-not (Test-Path 'node_modules')) {
  npm install
}
if (-not (Test-Path 'android')) {
  npx cap add android
}
npx cap sync android
npx cap open android
