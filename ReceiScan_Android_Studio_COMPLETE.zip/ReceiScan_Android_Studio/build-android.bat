@echo off
setlocal
where node || (echo Install Node.js first.& pause & exit /b 1)
where npm || (echo Install Node.js first.& pause & exit /b 1)
if not exist node_modules npm install
if not exist android npx cap add android
npx cap sync android
npx cap open android
