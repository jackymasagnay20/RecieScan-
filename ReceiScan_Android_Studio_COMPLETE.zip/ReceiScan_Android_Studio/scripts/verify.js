const fs = require('fs');
const path = require('path');
const html = path.join(__dirname, '..', 'www', 'index.html');
if (!fs.existsSync(html)) throw new Error('www/index.html is missing');
const s = fs.readFileSync(html, 'utf8');
if (!s.includes('<html') || !s.includes('</html>')) throw new Error('Invalid HTML document');
console.log('ReceiScan web source OK:', html);
