package com.receiscan.api.repository;
import com.receiscan.api.entity.TransactionEntity; import org.springframework.data.jpa.repository.JpaRepository;
public interface TransactionRepository extends JpaRepository<TransactionEntity,Long>{boolean existsByReference(String reference);}