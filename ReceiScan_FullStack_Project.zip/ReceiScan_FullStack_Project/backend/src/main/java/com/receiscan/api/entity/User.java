package com.receiscan.api.entity;
import jakarta.persistence.*;
@Entity @Table(name="users") public class User{
@Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id;
public String name; @Column(unique=true,nullable=false) public String email;
@Column(nullable=false) public String passwordHash; public String role;}