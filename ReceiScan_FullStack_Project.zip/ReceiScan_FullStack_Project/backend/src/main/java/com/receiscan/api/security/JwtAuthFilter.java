package com.receiscan.api.security;
import com.receiscan.api.repository.UserRepository; import jakarta.servlet.*; import jakarta.servlet.http.*;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken; import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder; import org.springframework.stereotype.Component; import org.springframework.web.filter.OncePerRequestFilter; import java.io.IOException; import java.util.List;
@Component public class JwtAuthFilter extends OncePerRequestFilter{
final JwtService jwt; final UserRepository users; public JwtAuthFilter(JwtService j,UserRepository u){jwt=j;users=u;}
protected void doFilterInternal(HttpServletRequest r,HttpServletResponse s,FilterChain c)throws ServletException,IOException{
String h=r.getHeader("Authorization");if(h!=null&&h.startsWith("Bearer ")){try{String e=jwt.email(h.substring(7));var u=users.findByEmail(e).orElse(null);if(u!=null)SecurityContextHolder.getContext().setAuthentication(new UsernamePasswordAuthenticationToken(u.email,null,List.of(new SimpleGrantedAuthority("ROLE_"+u.role))));}catch(Exception ignored){}}c.doFilter(r,s);}}