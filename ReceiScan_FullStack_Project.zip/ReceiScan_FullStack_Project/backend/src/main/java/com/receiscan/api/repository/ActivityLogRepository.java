package com.receiscan.api.repository;
import com.receiscan.api.entity.ActivityLog; import org.springframework.data.jpa.repository.JpaRepository;
public interface ActivityLogRepository extends JpaRepository<ActivityLog,Long>{long countByType(String type);}