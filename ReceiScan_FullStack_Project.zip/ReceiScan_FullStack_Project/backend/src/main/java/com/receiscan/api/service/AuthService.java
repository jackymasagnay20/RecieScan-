package com.receiscan.api.service;
import com.receiscan.api.entity.User; import com.receiscan.api.repository.UserRepository; import com.receiscan.api.security.JwtService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder; import org.springframework.stereotype.Service;
@Service public class AuthService{
final UserRepository users;final JwtService jwt;final BCryptPasswordEncoder enc=new BCryptPasswordEncoder();
public AuthService(UserRepository u,JwtService j){users=u;jwt=j;}
public User register(String n,String e,String p,String role){if(users.findByEmail(e).isPresent())throw new IllegalArgumentException("Email already registered.");User u=new User();u.name=n;u.email=e;u.passwordHash=enc.encode(p);u.role="OWNER".equalsIgnoreCase(role)?"OWNER":"STAFF";return users.save(u);}
public String login(String e,String p){User u=users.findByEmail(e).orElseThrow(()->new IllegalArgumentException("Invalid email or password."));if(!enc.matches(p,u.passwordHash))throw new IllegalArgumentException("Invalid email or password.");return jwt.generate(u.email,u.role);}}