package com.receiscan.api.controller;
import com.receiscan.api.service.AuthService; import org.springframework.web.bind.annotation.*; import java.util.Map;
@RestController @RequestMapping("/api/auth") public class AuthController{
final AuthService a;public AuthController(AuthService x){a=x;}
@PostMapping("/register")public Map<String,Object> register(@RequestBody Map<String,String>b){var u=a.register(b.get("name"),b.get("email"),b.get("password"),b.getOrDefault("role","STAFF"));return Map.of("message","Account created","role",u.role);}
@PostMapping("/login")public Map<String,Object> login(@RequestBody Map<String,String>b){return Map.of("token",a.login(b.get("email"),b.get("password")),"role","STAFF");}}