package com.receiscan.api.entity;
import jakarta.persistence.*;
@Entity @Table(name="transactions") public class TransactionEntity{
@Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id;
@Column(nullable=false) public String accountName; @Column(unique=true,nullable=false) public String reference;
@Column(nullable=false) public Double amount; public String date; public String time;
public String status="confirmed"; public String source="OCR"; @ManyToOne(fetch=FetchType.LAZY) public User createdBy;}