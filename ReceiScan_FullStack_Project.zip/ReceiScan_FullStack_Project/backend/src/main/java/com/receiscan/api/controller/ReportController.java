package com.receiscan.api.controller;
import com.receiscan.api.repository.*;import org.springframework.web.bind.annotation.*;import java.util.*;
@RestController @RequestMapping("/api/reports")public class ReportController{
final TransactionRepository tx;final ActivityLogRepository logs;public ReportController(TransactionRepository t,ActivityLogRepository l){tx=t;logs=l;}
@GetMapping("/summary")public Map<String,Object>summary(){double a=tx.findAll().stream().mapToDouble(x->x.amount).sum();return Map.of("transactions",tx.count(),"amount",String.format("%.2f",a),"duplicates",logs.countByType("duplicate"));}}