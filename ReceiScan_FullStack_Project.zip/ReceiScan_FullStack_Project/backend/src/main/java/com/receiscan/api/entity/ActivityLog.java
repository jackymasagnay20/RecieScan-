package com.receiscan.api.entity;
import jakarta.persistence.*; import java.time.LocalDateTime;
@Entity @Table(name="activity_logs") public class ActivityLog{
@Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id; public String action;
@Column(length=1000) public String description; public String type; public LocalDateTime createdAt=LocalDateTime.now();
@ManyToOne(fetch=FetchType.LAZY) public User user;}