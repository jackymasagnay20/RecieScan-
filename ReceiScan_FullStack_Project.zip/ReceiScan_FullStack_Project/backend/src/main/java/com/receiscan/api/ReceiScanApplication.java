package com.receiscan.api;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication public class ReceiScanApplication{public static void main(String[] a){SpringApplication.run(ReceiScanApplication.class,a);}}