Put your official logo file here and name it logo.png.
