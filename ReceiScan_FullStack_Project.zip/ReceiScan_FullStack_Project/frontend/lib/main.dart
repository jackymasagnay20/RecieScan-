import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'api_service.dart';

void main() => runApp(const ReceiScanApp());

class ReceiScanApp extends StatelessWidget {
  const ReceiScanApp({super.key});
  @override Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false, title: 'ReceiScan',
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF0869E8)),
      scaffoldBackgroundColor: const Color(0xFFF4F8FC), useMaterial3: true),
    home: const LoginPage());
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override State<LoginPage> createState()=>_LoginPageState();
}
class _LoginPageState extends State<LoginPage>{
  final e=TextEditingController(), p=TextEditingController(); bool loading=false; String error='';
  Future<void> login() async {
    setState(()=>loading=true);
    try { await ApiService.login(e.text.trim(),p.text); if(mounted) Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>const HomePage())); }
    catch(x){setState(()=>error=x.toString().replaceFirst('Exception: ',''));}
    finally{if(mounted)setState(()=>loading=false);}
  }
  @override Widget build(BuildContext c)=>Scaffold(body:Center(child:SingleChildScrollView(padding:const EdgeInsets.all(24),child:ConstrainedBox(
    constraints:const BoxConstraints(maxWidth:430),child:Card(child:Padding(padding:const EdgeInsets.all(28),child:Column(children:[
      Icon(Icons.receipt_long,size:76,color:Color(0xFF0869E8)),Text('ReceiScan',style:TextStyle(fontSize:32,fontWeight:FontWeight.bold,color:Color(0xFF073B82))),
      Text('Scan Receipts. Organize Records.',style:TextStyle(color:Colors.grey)),SizedBox(height:25),
      TextField(controller:e,decoration:InputDecoration(labelText:'Email',prefixIcon:Icon(Icons.email))),SizedBox(height:12),
      TextField(controller:p,obscureText:true,decoration:InputDecoration(labelText:'Password',prefixIcon:Icon(Icons.lock))),
      if(error.isNotEmpty) Text(error,style:const TextStyle(color:Colors.red)),SizedBox(height:18),
      SizedBox(width:double.infinity,child:FilledButton(onPressed:loading?null:login,child:Text(loading?'Signing in...':'Login'))),
      TextButton(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const RegisterPage())),child:const Text('Create new account'))
    ]))))));
}

class RegisterPage extends StatefulWidget{const RegisterPage({super.key});@override State<RegisterPage>createState()=>_RegisterPageState();}
class _RegisterPageState extends State<RegisterPage>{
 final n=TextEditingController(),e=TextEditingController(),p=TextEditingController();String role='STAFF',err='';bool loading=false;
 Future<void> go()async{setState(()=>loading=true);try{await ApiService.register(n.text.trim(),e.text.trim(),p.text,role);if(mounted){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Account created.')));Navigator.pop(context);}}catch(x){setState(()=>err=x.toString().replaceFirst('Exception: ',''));}finally{if(mounted)setState(()=>loading=false);}}
 @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Create Account')),body:Center(child:SingleChildScrollView(padding:const EdgeInsets.all(24),child:ConstrainedBox(constraints:const BoxConstraints(maxWidth:430),child:Card(child:Padding(padding:const EdgeInsets.all(24),child:Column(children:[
 TextField(controller:n,decoration:const InputDecoration(labelText:'Full name')),const SizedBox(height:12),
 TextField(controller:e,decoration:const InputDecoration(labelText:'Email')),const SizedBox(height:12),
 TextField(controller:p,obscureText:true,decoration:const InputDecoration(labelText:'Password')),const SizedBox(height:12),
 DropdownButtonFormField(value:role,items:const[DropdownMenuItem(value:'STAFF',child:Text('Staff')),DropdownMenuItem(value:'OWNER',child:Text('Owner'))],onChanged:(v)=>setState(()=>role=v!)),
 if(err.isNotEmpty)Text(err,style:const TextStyle(color:Colors.red)),const SizedBox(height:18),
 SizedBox(width:double.infinity,child:FilledButton(onPressed:loading?null:go,child:Text(loading?'Creating...':'Create Account')))
]))))));
}
}

class HomePage extends StatefulWidget{const HomePage({super.key});@override State<HomePage>createState()=>_HomePageState();}
class _HomePageState extends State<HomePage>{
 int i=0;final pages=const[DashboardPage(),ScanPage(),TransactionsPage(),ReportsPage()];
 @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('ReceiScan'),actions:[IconButton(icon:const Icon(Icons.logout),onPressed:()async{await ApiService.logout();if(mounted)Navigator.pushAndRemoveUntil(c,MaterialPageRoute(builder:(_)=>const LoginPage()),(_)=>false);})]),body:pages[i],
 bottomNavigationBar:NavigationBar(selectedIndex:i,onDestinationSelected:(x)=>setState(()=>i=x),destinations:const[
 NavigationDestination(icon:Icon(Icons.dashboard),label:'Dashboard'),NavigationDestination(icon:Icon(Icons.camera_alt),label:'Scan'),
 NavigationDestination(icon:Icon(Icons.receipt_long),label:'Transactions'),NavigationDestination(icon:Icon(Icons.bar_chart),label:'Reports')]));
}

class DashboardPage extends StatefulWidget{const DashboardPage({super.key});@override State<DashboardPage>createState()=>_DashboardPageState();}
class _DashboardPageState extends State<DashboardPage>{Map<String,dynamic>? d;@override void initState(){super.initState();load();}Future<void>load()async{try{final x=await ApiService.report();if(mounted)setState(()=>d=x);}catch(_){}}@override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(18),children:[
 Text('Dashboard',style:Theme.of(c).textTheme.headlineMedium),const SizedBox(height:16),
 Card(child:ListTile(leading:const Icon(Icons.receipt),title:const Text('Transactions'),trailing:Text('${d?['transactions']??0}'))),
 Card(child:ListTile(leading:const Icon(Icons.payments),title:const Text('Total Amount'),trailing:Text('₱${d?['amount']??'0.00'}'))),
 Card(child:ListTile(leading:const Icon(Icons.warning),title:const Text('Duplicate Attempts'),trailing:Text('${d?['duplicates']??0}'))),
]);}

class ScanPage extends StatefulWidget{const ScanPage({super.key});@override State<ScanPage>createState()=>_ScanPageState();}
class _ScanPageState extends State<ScanPage>{
 final picker=ImagePicker();final ocr=TextRecognizer(script:TextRecognitionScript.latin);bool processing=false,cancelled=false;String status='Capture or upload a receipt.';XFile? image;Map<String,String?>? result;
 Future<void> scan(ImageSource source)async{
  if(processing)return;setState(()=>{processing=true,cancelled=false,status='Reading receipt...',result=null});
  try{
   final f=await picker.pickImage(source:source,imageQuality:90,maxWidth:1800);if(f==null){setState(()=>processing=false);return;}image=f;
   if(cancelled)return;final text=await ocr.processImage(InputImage.fromFilePath(f.path));if(cancelled)return;
   final x=parse(text.text);if([x['account'],x['reference'],x['amount']].any((v)=>v==null||v!.isEmpty)){setState(()=>status='Could not clearly read Account Name, Reference Number and Amount. Scan again.');return;}
   setState(()=>status='Information read. Saving transaction automatically...');
   await ApiService.createTransaction(x['account']!,x['reference']!,double.parse(x['amount']!),x['date']!,x['time']!);
   if(cancelled)return;setState(()=>{result=x,processing=false,status='Transaction saved automatically.'});
   if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Transaction saved successfully.')));
  }catch(e){if(!cancelled)setState(()=>status='Scan failed: ${e.toString().replaceFirst('Exception: ','')}');}
  finally{if(mounted&&!cancelled&&processing)setState(()=>processing=false);}
 }
 void cancelScan(){cancelled=true;setState(()=>{processing=false,result=null,status='Scan cancelled. Ready for another receipt.'});}
 Map<String,String?> parse(String text){
  final ls=text.split(RegExp(r'\r?\n')).map((s)=>s.trim()).where((s)=>s.isNotEmpty).toList();String? a,r,amt;
  final rr=RegExp(r'(?:reference|ref\.?|transaction\s*(?:id|no)|receipt\s*(?:no|number)|confirmation)\s*(?:number|no\.?)?\s*[:#-]?\s*([0-9OoQqIl|Ss][0-9OoQqIl|Ss \-]{3,30})',caseSensitive:false);
  for(final l in ls){final m=rr.firstMatch(l);if(m!=null){r=m.group(1)!.replaceAll(RegExp(r'[^0-9]'),'').replaceAll(RegExp(r'[OoQq]'),'0').replaceAll(RegExp(r'[Il|]'),'1').replaceAll('S','5');if(r.length>=4)break;}}
  final ar=RegExp(r'\b(total\s*(?:amount|paid|payment)?|amount\s*(?:sent|paid)?|transfer\s*amount|payment\s*amount)\b\s*[:#-]?\s*(?:PHP|₱|P)?\s*([0-9][0-9,]*\.?[0-9]{0,2})',caseSensitive:false);
  for(final l in ls){final m=ar.firstMatch(l);if(m!=null){final v=double.tryParse(m.group(2)!.replaceAll(',',''));if(v!=null&&v>0){amt=v.toStringAsFixed(2);break;}}}
  final nr=RegExp(r'^(?:to|recipient|recipient name|receiver|beneficiary|merchant|account name|sent to|paid to|transferred to)\s*[:#-]?\s*([A-Za-z][A-Za-z .&\-]{2,})$',caseSensitive:false);
  for(final l in ls){final m=nr.firstMatch(l);if(m!=null){a=m.group(1)!.trim();break;}}
  return {'account':a,'reference':r,'amount':amt,'date':_date(ls),'time':_time(ls)};
 }
 String _date(List<String> l){final r=RegExp(r'\b(20\d{2}[-/]\d{1,2}[-/]\d{1,2}|\d{1,2}[-/]\d{1,2}[-/]20\d{2})\b');for(final x in l){final m=r.firstMatch(x);if(m!=null)return m.group(1)!;}return DateTime.now().toIso8601String().substring(0,10);}
 String _time(List<String> l){final r=RegExp(r'\b(\d{1,2}:\d{2}(?::\d{2})?\s*(?:AM|PM)?)\b',caseSensitive:false);for(final x in l){final m=r.firstMatch(x);if(m!=null)return m.group(1)!;}return TimeOfDay.now().format(context);}
 @override void dispose(){ocr.close();super.dispose();}
 @override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(18),children:[
 Text('Scan Receipt',style:Theme.of(c).textTheme.headlineMedium),const Text('Reads Account Name, Reference Number and Amount only.',style:TextStyle(color:Colors.grey)),const SizedBox(height:15),
 if(image!=null)ClipRRect(borderRadius:BorderRadius.circular(15),child:Image.file(File(image!.path),height:300,fit:BoxFit.contain))else Container(height:300,decoration:BoxDecoration(color:const Color(0xFF111B25),borderRadius:BorderRadius.circular(15)),child:const Icon(Icons.camera_alt,size:70,color:Colors.white)),
 const SizedBox(height:15),
 if(processing)...[const LinearProgressIndicator(),const SizedBox(height:10),Text(status,textAlign:TextAlign.center),OutlinedButton.icon(onPressed:cancelScan,icon:const Icon(Icons.close,color:Colors.red),label:const Text('Cancel Scan'))]
 else...[FilledButton.icon(onPressed:()=>scan(ImageSource.camera),icon:const Icon(Icons.camera_alt),label:const Text('Scan Receipt')),OutlinedButton.icon(onPressed:()=>scan(ImageSource.gallery),icon:const Icon(Icons.upload_file),label:const Text('Upload Receipt')),Text(status,textAlign:TextAlign.center)],
 if(result!=null)Card(margin:const EdgeInsets.only(top:15),child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Transaction Saved',style:TextStyle(color:Color(0xFF19B889),fontWeight:FontWeight.bold,fontSize:20)),Text('Account Name: ${result!['account']}'),Text('Reference Number: ${result!['reference']}'),Text('Amount: ₱${result!['amount']}')]))),
 ]);}
}

class TransactionsPage extends StatefulWidget{const TransactionsPage({super.key});@override State<TransactionsPage>createState()=>_TransactionsPageState();}
class _TransactionsPageState extends State<TransactionsPage>{List<dynamic> xs=[];@override void initState(){super.initState();load();}Future<void>load()async{try{final x=await ApiService.transactions();if(mounted)setState(()=>xs=x);}catch(_){}}@override Widget build(BuildContext c)=>RefreshIndicator(onRefresh:load,child:ListView(padding:const EdgeInsets.all(18),children:[Text('Transactions',style:Theme.of(c).textTheme.headlineMedium),...xs.map((t)=>Card(child:ListTile(title:Text('${t['accountName']} • ₱${t['amount']}'),subtitle:Text('Ref: ${t['reference']}\n${t['date']} ${t['time']}'))))]));}

class ReportsPage extends StatefulWidget{const ReportsPage({super.key});@override State<ReportsPage>createState()=>_ReportsPageState();}
class _ReportsPageState extends State<ReportsPage>{Map<String,dynamic>? d;@override void initState(){super.initState();load();}Future<void>load()async{try{final x=await ApiService.report();if(mounted)setState(()=>d=x);}catch(_){}}@override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(18),children:[Text('Reports',style:Theme.of(c).textTheme.headlineMedium),Card(child:ListTile(title:const Text('Transactions'),trailing:Text('${d?['transactions']??0}'))),Card(child:ListTile(title:const Text('Total Amount'),trailing:Text('₱${d?['amount']??'0.00'}'))),Card(child:ListTile(title:const Text('Duplicate Attempts'),trailing:Text('${d?['duplicates']??0}')))]);}
