import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ApiService {
  static const baseUrl = 'http://10.0.2.2:8080/api';

  static Future<String?> token() async =>
      (await SharedPreferences.getInstance()).getString('token');

  static Future<Map<String,dynamic>> request(
      String method, String path, {Map<String,dynamic>? body}) async {
    final t = await token();
    final headers = {
      'Content-Type': 'application/json',
      if (t != null) 'Authorization': 'Bearer $t'
    };
    final uri = Uri.parse('$baseUrl$path');
    final r = method == 'POST'
        ? await http.post(uri, headers: headers, body: jsonEncode(body ?? {}))
        : await http.get(uri, headers: headers);
    final data = r.body.isEmpty ? <String,dynamic>{} : jsonDecode(r.body);
    if (r.statusCode < 200 || r.statusCode >= 300) {
      throw Exception(data['message'] ?? 'Server request failed');
    }
    return Map<String,dynamic>.from(data);
  }

  static Future<void> login(String email, String password) async {
    final d = await request('POST', '/auth/login',
        body: {'email': email, 'password': password});
    final p = await SharedPreferences.getInstance();
    await p.setString('token', d['token']);
    await p.setString('role', d['role'] ?? 'STAFF');
  }

  static Future<void> register(
      String name, String email, String password, String role) async {
    await request('POST', '/auth/register',
        body: {'name': name, 'email': email, 'password': password, 'role': role});
  }

  static Future<void> logout() async =>
      (await SharedPreferences.getInstance()).clear();

  static Future<List<dynamic>> transactions() async =>
      (await request('GET', '/transactions'))['items'] ?? [];

  static Future<Map<String,dynamic>> report() async =>
      request('GET', '/reports/summary');

  static Future<void> createTransaction(
      String account, String reference, double amount, String date, String time) async {
    await request('POST', '/transactions', body: {
      'accountName': account, 'reference': reference, 'amount': amount,
      'date': date, 'time': time
    });
  }
}
