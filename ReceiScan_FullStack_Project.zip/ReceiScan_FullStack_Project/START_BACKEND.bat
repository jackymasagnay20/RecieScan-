@echo off
cd backend
mvn clean spring-boot:run
pause
