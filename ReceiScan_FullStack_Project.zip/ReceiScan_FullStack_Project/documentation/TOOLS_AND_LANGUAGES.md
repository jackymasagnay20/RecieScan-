# Languages and Tools

| Layer | Language | Tools |
|---|---|---|
| Frontend | Dart | Flutter, VS Code |
| OCR | Dart/native plugin | Google ML Kit Text Recognition |
| Backend | Java 17 | Spring Boot, Spring Security |
| API | JSON/HTTP | REST |
| Database | SQL | MySQL, MySQL Workbench |
| Build | Dart/Gradle | Flutter SDK, Android SDK |
| Backend build | XML/Java | Maven |

## Why each is used
**Dart/Flutter:** mobile UI, camera/gallery access, navigation and APK.
**ML Kit:** fast on-device receipt text recognition.
**Java/Spring Boot:** REST API, authentication, duplicate checking and transaction storage.
**MySQL:** persistent users, transactions and activity logs.
**VS Code:** code editing and terminal workflow.
**Android Studio:** Android SDK/emulator and Android build support.
**Maven:** backend dependency management and running Spring Boot.
