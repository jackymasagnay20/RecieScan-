# API Documentation

Base URL: `http://localhost:8080/api`

### POST /auth/register
Creates an account.
```json
{"name":"Staff User","email":"staff@example.com","password":"password123","role":"STAFF"}
```

### POST /auth/login
```json
{"email":"staff@example.com","password":"password123"}
```
Returns a JWT token.

Protected endpoints use:
`Authorization: Bearer <token>`

### GET /transactions
Returns saved transactions.

### POST /transactions
```json
{"accountName":"Juan Dela Cruz","reference":"123456789","amount":500.00,"date":"2026-09-21","time":"15:30"}
```
The backend rejects duplicate reference numbers.

### GET /reports/summary
Returns transaction count, total amount and duplicate attempts.
