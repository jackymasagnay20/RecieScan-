# ReceiScan Full-Stack Documentation

## Separate components
- **Frontend:** Flutter + Dart Android application
- **Backend:** Java 17 + Spring Boot REST API
- **Database:** MySQL
- **OCR:** Google ML Kit Text Recognition on the phone

## Main workflow
Scan/Upload Receipt -> OCR -> Account Name + Reference Number + Amount -> Duplicate Check -> Automatic Save -> Transactions/Reports.

## Tools
VS Code, Flutter SDK, Android Studio/Android SDK, JDK 17, Maven, MySQL Server, MySQL Workbench, Git.

## Setup
1. Run `database/receiscan.sql` in MySQL Workbench.
2. Edit `backend/src/main/resources/application.properties` and enter the MySQL password.
3. In `backend`, run `mvn clean spring-boot:run`.
4. In `frontend`, run `flutter pub get` then `flutter run`.
5. For a physical phone, change `ApiService.baseUrl` from `10.0.2.2` to the PC's LAN IP, e.g. `http://192.168.1.10:8080/api`.
6. Build APK with `flutter build apk --release`.

## Important
The starter allows role selection at registration for development. For production, OWNER creation must be restricted by backend authorization. Use HTTPS and a strong private JWT secret in production.
